require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const app = express();

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3000;
const EMAIL = process.env.EMAIL;
const PASSWORD = process.env.PASSWORD;

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/homepage.html');
});

app.get('/booking', (req, res) => {
  res.sendFile(__dirname + '/views/contact.html');
})

app.post('/send-email', (req, res) => {
  const { name, email, phone, dayTime, tours, specialRequest } = req.body;

  const userEmail = email;

  // Configure nodemailer
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    Port: 587,
    auth: {
      user: EMAIL,
      pass: PASSWORD
    }
  });

  // Format the subject with dynamic information from the form submission
  const subject = `NEW TOUR: ${name} wants to book tours on ${dayTime}`;

  let mailOptions = {
    from: userEmail,
    to: EMAIL,
    subject: subject,
    html: `
      <p>Name: ${name}</p>
      <p>Email: ${email}</p>
      <p>Phone: ${phone}</p>
      <p>Day and Time: ${dayTime}</p>
      <p>Selected Tours: ${tours}</p>
      <p>Special Request: ${specialRequest}</p>
    `
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.send('Error. There is something wrong with your input. Check it again!');
    } else {
      console.log('Email sent: ' + info.response);
      res.send('Success! Thanks for choosing us. We will contact you asap. Welcome to Vietnam!');
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
