/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./views/**/*.html", // Path to your Handlebars templates
    // Add other paths as needed
    // For example, if you dynamically inject class names via JavaScript:
    "./public/**/*.js",
  ],
  theme: {
    extend: {
      colors: {
        // Define your custom colors here
        brand: '#FFA700',
      },
      listStyleImage: {
        checkmark: 'url("/images/Check.svg")',
      },
    },
  },
  plugins: [],
}

